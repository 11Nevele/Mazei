#ifndef DIRECTION_HPP
#define DIRECTION_HPP

enum Direction
{
  left, front, right, back
};

#endif