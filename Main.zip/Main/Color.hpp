#ifndef COLOR_HPP
#define COLOR_HPP

enum Color
{
  red, blue, green, white, black, unknown
};

#endif